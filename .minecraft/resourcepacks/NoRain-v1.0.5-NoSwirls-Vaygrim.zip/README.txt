======
This is the NoRain Pack, simply made for removing Rain texture and noise. It also removes the swirls that you see when you have a Potion effect applied.

======
License:

The NoRain Resource Pack is licensed under Calclavia's Educational Public License (as seen in the file LICENSE.txt as well as at https://github.com/Vexatos/BevoPack/blob/master/LICENSE.md). By using or interacting with this software in any way shape or form, you agree to the license of this software.

======
Thank you for reading this, have fun!
Sincerely,
Vexatos
